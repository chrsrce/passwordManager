import "./App.css";
import {Routes, Route, Link} from "react-router-dom";
import NewCreds from "./components/NewCreds";
import Login from './components/Login';
import About from './components/About'; //filler
import NoMatch from './components/NoMatch'; //catchall
import SignUp from './components/SignUp';

function App() {
    return (
        <div className="App">
            {/*<nav>
                <Link to ="/"> Home </Link> |
                <Link to ="/about"> About </Link>
            </nav>*/}
            <Routes>
                <Route path="/" element={<NewCreds/>}/> {/*initial page*/}
                <Route path="/Login" element={<Login/>}/>
                <Route path="/SignUp" element={<SignUp/>}/>
                <Route path="/NewCred" element={<NewCreds/>}/> {/*initial page*/}
                <Route path ="*" element={<NoMatch/>}/>
            </Routes>
        </div>
    );
}

export default App;