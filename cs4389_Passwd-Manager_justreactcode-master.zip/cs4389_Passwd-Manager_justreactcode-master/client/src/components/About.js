import React from 'react';

function About () {
    return <div>
        <h2>This is the about page</h2>
    </div>
}
export default About;