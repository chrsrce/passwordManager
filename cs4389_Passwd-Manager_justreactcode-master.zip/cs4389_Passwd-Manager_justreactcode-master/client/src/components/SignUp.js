import React, {useEffect, useState} from 'react';
import Axios from "axios";

function SignUp (){
    const [email, setEmail] = useState("");
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [errMsg, setErrMsg] = useState("");

    /* //may be useful for on-page alerts rather than popup?
    useEffect(() => {
        const timeOutId = setTimeout(() => setDisplayMessage(query), 500);
        return () => clearTimeout(timeOutId);
    }, [query]);
    */

    const signUp = () => {
        console.log("signup")
        Axios.post("http://localhost:3331/signup", {
            email: email,
            username: username,
            password: password,
        });
    }

    const validateFormInput = () => { //still need to check user
        if (password !== confirmPassword) {
            alert("Passwords don't match");
        }
        Axios.post("http://localhost:3331/emailunused", {
            email: email}).then((response) => {
            console.log(response.data)
            if(response.data[0]["COUNT(*)"] !== 0)
                alert("Email already used")
            else
                signUp();
        })
    }

    return <div className="SigningUp"> {/*might add html form?*/}
        <h1>Sign up below</h1>
        <input
            type="email"
            placeholder="Email"
            onChange={(event) => {
                setEmail(event.target.value);
            }}
        />
        <input
            type="text"
            placeholder="Username"
            onChange={(event) => {
                setUsername(event.target.value);
            }}
        />
        <input
            type="password"
            placeholder="Password"
            onChange={(event) => {
                setPassword(event.target.value);
            }}
        />
        <input
            type="password"
            placeholder="Re-enter Password"
            onChange={(event) => {
                setConfirmPassword(event.target.value);
            }}
        />
        <button onClick={() => validateFormInput()}> signup</button>
    </div>
}

export default SignUp;