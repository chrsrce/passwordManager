import React from "react"

export default function NoMatch() {
    return <h1> This is 404 </h1>
}