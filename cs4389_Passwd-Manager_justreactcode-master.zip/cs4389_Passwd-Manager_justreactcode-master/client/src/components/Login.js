import React, {useState} from 'react';
import Axios from "axios";

function Login (){
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const login = () => {
        Axios.post("http://localhost:3331/login", {
            username: username,
            password: password,
        }).then((response) => {
            console.log(response.data)
            if(response.data[0]["COUNT(*)"] === 0)
                alert("Account not found")
            else
                alert("Successful login")
        });
    };

    return <div className="LoggingIn">
        <h1>Welcome to the password manager!</h1>
        <input
            type="text"
            placeholder="Username"
            onChange={(event) => {
                setUsername(event.target.value);
            }}
        />
        <input
            type="password"
            placeholder="Password"
            onChange={(event) => {
                setPassword(event.target.value);
            }}
        />
        <button onClick={login}> Login</button>
    </div>
}

export default Login;