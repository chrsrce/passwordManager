import React, {useEffect, useState} from 'react';
import Axios from "axios";

function NewCreds () {
    const [title, setTitle] = useState("");
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState(""); //initally "", use setPassword to trigger updated current password
    const [email, setEmail] = useState("");
    const [url, setUrl] = useState("");
    const [notes, setNotes] = useState("");

    useEffect(() => { //test to view passwords table
        Axios.get("http://localhost:3331/getpassword").then((response) => {
            console.log(response.data);
        });
    }, []);

    const addPassword = () => { //funct named addPassword w/ no para
        Axios.post("http://localhost:3331/addpassword", { //post pass/title to /addpassword
            password: password,
            title: title,
        });
    };

    const addCred = () => {
        Axios.post("http://localhost:3331/addcred", {
            title: title,
            username: username,
            password: password,
            email: email,
            url: url,
            notes: notes,
        });
    };
    return <div className="AddingCred">
        <h1>Add another credential</h1>
        <input
            type="text"
            placeholder="Title"
            onChange={(event) => {
                setTitle(event.target.value);
            }}
        />
        <input
            type="text"
            placeholder="Username"
            onChange={(event) => {
                setUsername(event.target.value);
            }}
        />
        <input
            type="password"
            placeholder="Password"
            onChange={(event) => {
                setPassword(event.target.value); //get input that triggered event (basically anything bc onChange)
            }}
        />
        <input
            type="text"
            placeholder="Email"
            onChange={(event) => {
                setEmail(event.target.value); //get input that triggered event (basically anything bc onChange)
            }}
        />
        <input
            type="text"
            placeholder="URL"
            onChange={(event) => {
                setUrl(event.target.value);
            }}
        />
        <input
            type="text"
            placeholder="Notes"
            onChange={(event) => {
                setNotes(event.target.value);
            }}
        />
        <button onClick={addPassword}> Add Account</button>
    </div>
}
export default NewCreds;