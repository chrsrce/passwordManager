import React from "react"
import Axios from "axios";

export default function ViewAccount() {
    return <div className="ViewingAccount">
    </div>
}