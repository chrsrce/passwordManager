import React, {useEffect, useState} from 'react';
import Axios from "axios";
import {Link, Navigate, useNavigate} from "react-router-dom";

function SignUp (){
    const [email, setEmail] = useState("");
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [authenticated, setauthenticated] = useState(null);
    const [errMsg, setErrMsg] = useState("");
    const navigate = useNavigate();

    /* //may be useful for on-page alerts rather than popup?
    useEffect(() => {
        const timeOutId = setTimeout(() => setDisplayMessage(query), 500);
        return () => clearTimeout(timeOutId);
    }, [query]);
    */

    useEffect(() => {
        const loggedInUser = localStorage.getItem("authenticated");
        if (loggedInUser) {
            setauthenticated(loggedInUser);
        }
    }, []);

    const signUp = () => {
        console.log("signup")
        Axios.post("http://localhost:3331/signup", {
            email: email,
            username: username,
            password: password,
        });
        navigate("/Login");
    }

    const validateFormInput = (event) => { //still need to check user
        event.preventDefault()
        if (password !== confirmPassword) {
            alert("Passwords don't match");
        }
        else {
            Axios.post("http://localhost:3331/emailunused", {
                email: email
            }).then((response) => {
                console.log(response.data)
                if (response.data[0]["COUNT(*)"] !== 0)
                    alert("Email already used")
                else
                    signUp();
            })
        }
    }

    if (authenticated === "true") { //cant access sign up page if logged in
        console.log("auth")
        return <Navigate replace to="/NewCred" />; //maybe add page for no perms, or just redirect to 404
    }
    else {
        return <div className="FormatPage">
            <div className="SigningUp">
                <Link to="/Login">Already have an account? Log in</Link>
                <h1>Sign up below</h1>
                <form onSubmit={validateFormInput}>
                    <label>
                        Email Address
                        <input
                            required
                            type="email"
                            onChange={(event) => {
                                setEmail(event.target.value);
                            }}
                        />
                    </label>
                    <label>
                        Username
                        <input
                            required
                            type="text"
                            onChange={(event) => {
                                setUsername(event.target.value);
                            }}
                        />
                    </label>
                    <label>
                        Password
                        <input
                            required
                            type="password"
                            onChange={(event) => {
                                setPassword(event.target.value);
                            }}
                        />
                    </label>
                    <label>
                        Re-enter Password
                        <input
                            required
                            type="password"
                            onChange={(event) => {
                                setConfirmPassword(event.target.value);
                            }}
                        />
                    </label>
                    <input type="submit" value="Sign Up"/>
                </form>
            </div>
        </div>
    }
}

export default SignUp;