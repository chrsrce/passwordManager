const express = require("express");
const app = express();
const mysql = require("mysql");
const cors = require("cors");
const PORT = 3331;

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
    user: "root",
    host: "localhost",
    password: "password",
    database: "PasswordManager",
});

app.post("/signup", (req, res) => {
    const { email, username, password } = req.body;
    db.query(
        "INSERT INTO Master_account (email, username, password) VALUES (?,?,?)",
        [email, username, password],
        (err, result) => {
            if (err)
                console.log(err);
            else {
                res.send("Success");
            }
        }
    );
});

app.post("/login", (req, res) => {
    const { username, password } = req.body;
    db.query(
        "SELECT * FROM Master_account WHERE Username=? && Password=?",
        [username, password],
        (err, result) => {
            if (err)
                console.log(err);
            else {
                res.send(result);
            }
        }
    );
});

app.post("/emailunused", (req, res) => {
    const { email } = req.body;
    db.query(
        "SELECT COUNT(*) FROM Master_account WHERE Email=?",
        [email],
        (err, result) => {
            if (err)
                console.log(err);
            else {
                res.send(result)
            }
        }
    );
});

app.post("/usernameunused", (req, res) => {
    const { username } = req.body;
    db.query(
        "SELECT COUNT(*) FROM Master_account WHERE Username=?",
        [username],
        (err, result) => {
            if (err)
                console.log(err);
            else {
                res.send(result)
            }
        }
    );
});

app.post("/addcred", (req, res) => { //untested
    const { master_email, title, username, password, email, url, notes } = req.body;
    db.query(
        "INSERT INTO Login (master_email, title, username, password, email, url, notes) VALUES (?,?,?,?,?,?,?)",
        [master_email, title, username, password, email, url, notes],
        (err, result) => {
            if (err)
                console.log(err);
            else
                res.send("Success");
        }
    );
});

app.post("/getcred", (req, res) => { //untested
    const { master_email, title} = req.body;
    db.query(
        "SELECT * FROM Login WHERE master_email=?",
        [master_email],
        (err, result) => {
            if (err)
                console.log(err);
            else
                res.send(result);
        }
    );
});

app.listen(PORT, () => {
    console.log("Server is running");
});